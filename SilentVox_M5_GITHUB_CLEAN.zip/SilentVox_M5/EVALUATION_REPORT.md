# SilentVox P5 — Evaluation, Robustness + UNKNOWN

## QC status

- Evaluation manifest: **missing** (0 rows)

- Random Forest artifact: **NOT FOUND**

- CNN artifact: **NOT FOUND**


> **P5 is not fully executable on the supplied archive.** The archive contains the M5 acoustic simulation, but no identifiable RF/CNN classifier artifacts and no labeled evaluation dataset/manifest. No accuracy, F1, latency, UNKNOWN, or generalization result is fabricated. Add the classifier artifacts and held-out evaluation audio/manifest, then rerun this script.


## Required methodology

P5 evaluates both classifiers on the same held-out test set. It records accuracy, macro precision/recall, macro-F1, per-class F1, confusion matrices, median and P90 per-sample CPU inference latency, serialized model size, and process RAM. Resource measurements are reported as measurements, not estimates.


### Confusion analysis

For every non-diagonal confusion, P5 ranks the pair and records an investigation note covering data overlap, label ambiguity, feature similarity, and model capacity. The note is a hypothesis to be validated against examples; it is not presented as a proven cause without evidence.


### UNKNOWN detection

The rule is `confidence < threshold → UNKNOWN`. The threshold is selected only on validation data containing in-taxonomy known samples and out-of-taxonomy OOD samples. Test data are not used for threshold selection. The report includes false-confident OOD classifications, OOD unknown-detection rate, known rejection rate, and confidence distributions.


### Generalization

Where manifest metadata exists, evaluation is stratified by recording device, distance, direction, volume, environment, noise source, and SNR. Missing metadata is reported as unavailable rather than inferred.


## Current archive limitation

The supplied `SilentVox_M5` archive is an acoustic-modeling project. Its documented artifacts are simulated speaker/secondary-path/leakage models; those are not a Random Forest or CNN classifier and cannot be substituted for classifier predictions.
