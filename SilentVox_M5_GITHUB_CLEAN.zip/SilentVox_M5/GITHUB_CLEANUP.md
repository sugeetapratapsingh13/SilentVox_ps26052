# GitHub repository hygiene

This repository intentionally excludes local Python virtual environments, OS metadata, Python bytecode, IDE settings, caches, secrets, and runtime logs.

Install dependencies with:

```bash
python -m pip install -r requirements.txt
```

Do not commit `.env` files or credentials.
