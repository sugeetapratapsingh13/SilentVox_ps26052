import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import freqz


# ============================================================
# SILENTVOX M5 - SECONDARY PATH DELAY EXPERIMENT
# ============================================================

SAMPLE_RATE = 16000
FILTER_LENGTH = 256
ATTENUATION = 0.65

DELAYS_MS = [0, 1, 2, 5, 10]


# Frequency response frequencies
frequencies = np.linspace(
    20,
    SAMPLE_RATE / 2,
    2000
)


# ============================================================
# CREATE DELAYED SECONDARY PATH
# ============================================================

phase_results = {}
magnitude_results = {}

for delay_ms in DELAYS_MS:

    delay_samples = int(
        SAMPLE_RATE * delay_ms / 1000
    )

    impulse = np.zeros(FILTER_LENGTH)

    if delay_samples >= FILTER_LENGTH:
        raise ValueError(
            f"{delay_ms} ms exceeds filter length."
        )

    impulse[delay_samples] = ATTENUATION

    w, h = freqz(
        impulse,
        worN=4096,
        fs=SAMPLE_RATE
    )

    magnitude_db = (
        20
        * np.log10(
            np.maximum(
                np.abs(h),
                1e-10
            )
        )
    )

    phase_deg = np.unwrap(
        np.angle(h)
    ) * 180 / np.pi

    magnitude_results[delay_ms] = np.interp(
        frequencies,
        w,
        magnitude_db
    )

    phase_results[delay_ms] = np.interp(
        frequencies,
        w,
        phase_deg
    )


# ============================================================
# PRINT RESULTS
# ============================================================

print("=" * 65)
print("SILENTVOX M5 - DELAY EXPERIMENT")
print("=" * 65)

print()
print("Sample rate:", SAMPLE_RATE, "Hz")
print("Filter length:", FILTER_LENGTH, "samples")
print("Attenuation:", ATTENUATION)

print()
print("Delay configuration:")

for delay_ms in DELAYS_MS:

    delay_samples = int(
        SAMPLE_RATE * delay_ms / 1000
    )

    print(
        f"{delay_ms:>2} ms "
        f"→ {delay_samples:>3} samples"
    )


# ============================================================
# PLOT 1 - PHASE RESPONSE
# ============================================================

plt.figure(figsize=(11, 6))

for delay_ms in DELAYS_MS:

    plt.plot(
        frequencies,
        phase_results[delay_ms],
        linewidth=2,
        label=f"{delay_ms} ms"
    )

plt.title(
    "SilentVox M5 - Effect of Secondary-Path Delay"
)

plt.xlabel("Frequency (Hz)")
plt.ylabel("Phase (degrees)")

plt.grid(
    True,
    alpha=0.3
)

plt.legend(
    title="Delay"
)

plt.tight_layout()

plt.savefig(
    "plots/delay_phase_comparison.png",
    dpi=300
)

plt.show()


# ============================================================
# PLOT 2 - MAGNITUDE RESPONSE
# ============================================================

plt.figure(figsize=(11, 6))

for delay_ms in DELAYS_MS:

    plt.plot(
        frequencies,
        magnitude_results[delay_ms],
        linewidth=2,
        label=f"{delay_ms} ms"
    )

plt.title(
    "SilentVox M5 - Delay Experiment Magnitude Response"
)

plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude (dB)")

plt.grid(
    True,
    alpha=0.3
)

plt.legend(
    title="Delay"
)

plt.tight_layout()

plt.savefig(
    "plots/delay_magnitude_comparison.png",
    dpi=300
)

plt.show()


# ============================================================
# SAVE RESULTS
# ============================================================

phase_output = np.column_stack(
    [
        frequencies
    ]
    + [
        phase_results[d]
        for d in DELAYS_MS
    ]
)

magnitude_output = np.column_stack(
    [
        frequencies
    ]
    + [
        magnitude_results[d]
        for d in DELAYS_MS
    ]
)


np.savetxt(
    "results/delay_phase_results.csv",
    phase_output,
    delimiter=",",
    header=(
        "Frequency_Hz,"
        + ",".join(
            f"Phase_{d}ms"
            for d in DELAYS_MS
        )
    ),
    comments=""
)


np.savetxt(
    "results/delay_magnitude_results.csv",
    magnitude_output,
    delimiter=",",
    header=(
        "Frequency_Hz,"
        + ",".join(
            f"Magnitude_{d}ms"
            for d in DELAYS_MS
        )
    ),
    comments=""
)


print()
print("OUTPUT FILES CREATED:")
print("--------------------------------")
print("plots/delay_phase_comparison.png")
print("plots/delay_magnitude_comparison.png")
print("results/delay_phase_results.csv")
print("results/delay_magnitude_results.csv")

print()
print("Delay experiment completed successfully.")