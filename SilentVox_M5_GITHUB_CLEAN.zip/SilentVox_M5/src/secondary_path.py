import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import freqz


# ============================================================
# SILENTVOX M5 - SIMULATED SECONDARY PATH MODEL
# ============================================================
# IMPORTANT:
# This is a SIMULATED secondary-path estimate S_hat(z).
# It is NOT a physical measurement.
#
# Physical validation with the actual speaker, enclosure,
# acoustic path, and error microphone is required later.
# ============================================================


# ------------------------------------------------------------
# Basic configuration
# ------------------------------------------------------------

SAMPLE_RATE = 16000

# Simulated acoustic delay
DELAY_MS = 2.0

# Overall acoustic attenuation
ATTENUATION = 0.65

# Filter length
FILTER_LENGTH = 128


# ------------------------------------------------------------
# Convert delay from milliseconds to samples
# ------------------------------------------------------------

DELAY_SAMPLES = int(
    SAMPLE_RATE * DELAY_MS / 1000
)


# ------------------------------------------------------------
# Create frequency axis
# ------------------------------------------------------------

frequencies = np.linspace(
    0,
    SAMPLE_RATE / 2,
    2000
)


# ============================================================
# CREATE SIMULATED SECONDARY-PATH IMPULSE RESPONSE
# ============================================================

secondary_path = np.zeros(FILTER_LENGTH)

# Acoustic delay
if DELAY_SAMPLES < FILTER_LENGTH:

    secondary_path[DELAY_SAMPLES] = ATTENUATION

else:

    raise ValueError(
        "Delay is longer than the filter length."
    )


# ------------------------------------------------------------
# Add a small acoustic tail
# ------------------------------------------------------------

tail_start = DELAY_SAMPLES + 1

if tail_start < FILTER_LENGTH:

    tail_length = FILTER_LENGTH - tail_start

    tail = (
        ATTENUATION
        * 0.25
        * np.exp(
            -np.linspace(0, 5, tail_length)
        )
    )

    secondary_path[tail_start:] = tail


# ============================================================
# FREQUENCY RESPONSE
# ============================================================

w, h = freqz(
    secondary_path,
    worN=4096,
    fs=SAMPLE_RATE
)

magnitude_db = 20 * np.log10(
    np.maximum(np.abs(h), 1e-10)
)

phase_deg = np.unwrap(
    np.angle(h)
) * 180 / np.pi


# ============================================================
# PRINT MODEL INFORMATION
# ============================================================

print("=" * 65)
print("SILENTVOX M5 - SECONDARY PATH MODEL")
print("=" * 65)

print(f"Sample rate          : {SAMPLE_RATE} Hz")
print(f"Acoustic delay       : {DELAY_MS} ms")
print(f"Delay samples        : {DELAY_SAMPLES}")
print(f"Attenuation factor   : {ATTENUATION}")
print(f"Filter length        : {FILTER_LENGTH} samples")

print()
print("MODEL STATUS:")
print("SIMULATED SECONDARY-PATH ESTIMATE")
print("Physical measurement : PENDING")
print("Speaker validation   : PENDING")
print("Error-microphone validation : PENDING")


# ============================================================
# SAVE SECONDARY-PATH MODEL
# ============================================================

np.save(
    "models/secondary_path_estimate.npy",
    secondary_path
)


# ============================================================
# SAVE FREQUENCY RESPONSE
# ============================================================

results = np.column_stack(
    (
        w,
        magnitude_db,
        phase_deg
    )
)

np.savetxt(
    "results/secondary_path_response.csv",
    results,
    delimiter=",",
    header="Frequency_Hz,Magnitude_dB,Phase_deg",
    comments=""
)


# ============================================================
# PLOT 1 - MAGNITUDE RESPONSE
# ============================================================

plt.figure(figsize=(10, 6))

plt.plot(
    w,
    magnitude_db,
    linewidth=2
)

plt.title(
    "SilentVox M5 - Simulated Secondary Path Magnitude"
)

plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude (dB)")

plt.grid(True, alpha=0.3)

plt.tight_layout()

plt.savefig(
    "plots/secondary_path_magnitude.png",
    dpi=300
)

plt.show()


# ============================================================
# PLOT 2 - PHASE RESPONSE
# ============================================================

plt.figure(figsize=(10, 6))

plt.plot(
    w,
    phase_deg,
    linewidth=2
)

plt.title(
    "SilentVox M5 - Simulated Secondary Path Phase"
)

plt.xlabel("Frequency (Hz)")
plt.ylabel("Phase (degrees)")

plt.grid(True, alpha=0.3)

plt.tight_layout()

plt.savefig(
    "plots/secondary_path_phase.png",
    dpi=300
)

plt.show()


# ============================================================
# FINAL MESSAGE
# ============================================================

print()
print("OUTPUT FILES CREATED:")
print("---------------------------------")
print("models/secondary_path_estimate.npy")
print("results/secondary_path_response.csv")
print("plots/secondary_path_magnitude.png")
print("plots/secondary_path_phase.png")

print()
print("Secondary-path simulation completed.")