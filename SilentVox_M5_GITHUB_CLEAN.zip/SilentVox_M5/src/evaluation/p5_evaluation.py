#!/usr/bin/env python3
"""
SilentVox P5 — Evaluation, Robustness and UNKNOWN detection
==============================================================

This module is intentionally evaluation-only: it never trains or modifies
a classifier. It evaluates an existing Random Forest and CNN, measures
resource usage, investigates confusions, tunes an UNKNOWN threshold using
held-out in-taxonomy validation audio plus out-of-taxonomy audio, and
runs robustness/generalization tests when metadata is available.

Expected evaluation manifest (CSV):
  filepath,label,split,device,distance,direction,volume,environment,
  noise_source,snr_db

Only filepath and label are mandatory. split should be train/val/test/ood
when available. Metadata columns enable Part D. OOD rows are outside the
training taxonomy and must not use training labels.

Examples:
  python src/evaluation/p5_evaluation.py --root .
  python src/evaluation/p5_evaluation.py --root . --manifest data/manifest.csv
  python src/evaluation/p5_evaluation.py --root . --manifest ... \
      --rf models/random_forest.joblib --cnn models/cnn.pt
"""
from __future__ import annotations
import argparse, csv, json, math, os, pickle, platform, statistics, sys, time, tracemalloc
from pathlib import Path
from collections import Counter, defaultdict

import numpy as np

try:
    import psutil
except Exception:
    psutil = None

try:
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, f1_score,
        confusion_matrix
    )
except Exception:
    accuracy_score = precision_score = recall_score = f1_score = confusion_matrix = None

AUDIO_EXTS = {".wav", ".flac", ".mp3", ".ogg", ".m4a", ".aiff", ".aif"}
REQUIRED_META = ["device", "distance", "direction", "volume", "environment", "noise_source", "snr_db"]

def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})

def load_manifest(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError("Manifest is empty.")
    if "filepath" not in rows[0] or "label" not in rows[0]:
        raise ValueError("Manifest must contain filepath and label columns.")
    for r in rows:
        r["filepath"] = str(r["filepath"])
        r["label"] = str(r["label"])
        r["split"] = str(r.get("split", "")).lower()
    return rows

def discover_manifest(root):
    """Best-effort directory-label discovery; metadata remains unknown."""
    audio = []
    data_dirs = [root / "data", root / "dataset", root / "datasets", root / "audio"]
    for d in data_dirs:
        if d.exists():
            audio.extend(p for p in d.rglob("*") if p.suffix.lower() in AUDIO_EXTS)
    if not audio:
        return []
    rows=[]
    for p in audio:
        rel=p.relative_to(root)
        parts=rel.parts
        label=parts[-2] if len(parts)>=2 else "UNKNOWN_LABEL"
        split=""
        for s in ("train","val","validation","test","ood","unknown"):
            if s in {x.lower() for x in parts}:
                split="val" if s=="validation" else s
                break
        rows.append({"filepath":str(rel),"label":label,"split":split})
    return rows

def audio_features(paths, sr=16000, n_mels=64, duration=2.0):
    """
    Generic deterministic feature extractor. It is suitable only when the
    supplied classifier was trained on compatible features. If a project's
    training pipeline uses a different representation, configure an adapter.
    """
    try:
        import librosa
    except Exception as e:
        raise RuntimeError("librosa is required for generic audio evaluation") from e
    out=[]
    for p in paths:
        y, _ = librosa.load(p, sr=sr, mono=True, duration=duration)
        if y.size == 0:
            y=np.zeros(int(sr*duration), dtype=np.float32)
        y=librosa.util.fix_length(y, size=int(sr*duration))
        mel=librosa.feature.melspectrogram(y=y, sr=sr, n_mels=n_mels, n_fft=1024, hop_length=256, power=2.0)
        lm=librosa.power_to_db(mel, ref=np.max)
        mfcc=librosa.feature.mfcc(S=lm, n_mfcc=13)
        zcr=float(np.mean(librosa.feature.zero_crossing_rate(y)))
        centroid=float(np.mean(librosa.feature.spectral_centroid(y=y,sr=sr)))
        bandwidth=float(np.mean(librosa.feature.spectral_bandwidth(y=y,sr=sr)))
        feat=np.concatenate([lm.mean(1), lm.std(1), mfcc.mean(1), mfcc.std(1),
                             [zcr, centroid/sr, bandwidth/sr]]).astype(np.float32)
        out.append(feat)
    return np.vstack(out)

def load_pickle_model(path):
    with open(path,"rb") as f:
        return pickle.load(f)

def load_model(path, kind):
    path=Path(path)
    suffix=path.suffix.lower()
    if kind=="rf":
        try:
            import joblib
            return joblib.load(path)
        except Exception:
            return load_pickle_model(path)
    if kind=="cnn":
        try:
            import torch
            obj=torch.load(path, map_location="cpu", weights_only=False)
            return ("torch", obj)
        except Exception as e:
            raise RuntimeError(f"Could not load CNN {path}: {e}")
    raise ValueError(kind)

def model_size_bytes(path):
    return Path(path).stat().st_size

def get_memory_mb():
    if psutil:
        return psutil.Process(os.getpid()).memory_info().rss / (1024**2)
    return float("nan")

def predict_rf(model, X):
    pred=np.asarray(model.predict(X))
    if hasattr(model,"predict_proba"):
        proba=np.asarray(model.predict_proba(X))
        classes=np.asarray(getattr(model,"classes_", np.arange(proba.shape[1])))
    else:
        proba=None; classes=None
    return pred, proba, classes

def predict_torch(obj, X):
    import torch
    if isinstance(obj, tuple) and obj and obj[0]=="torch": obj=obj[1]
    model=obj
    if isinstance(model, dict):
        raise RuntimeError("CNN checkpoint is a state_dict/dict. Provide a project-specific CNN adapter.")
    model.eval()
    xt=torch.tensor(X,dtype=torch.float32)
    with torch.no_grad():
        y=model(xt)
        if isinstance(y,(tuple,list)): y=y[0]
        prob=torch.softmax(y,dim=1).cpu().numpy()
    pred_idx=prob.argmax(1)
    return pred_idx, prob, np.arange(prob.shape[1])

def map_predictions(pred, classes, labels):
    if classes is None:
        return pred.astype(str)
    classes_arr=np.asarray(classes)
    return np.asarray([str(classes_arr[int(i)]) if 0 <= int(i) < len(classes_arr) else str(i) for i in pred])

def metrics_rows(model_name, y_true, y_pred, labels, proba=None):
    rows=[]
    rows.append({"model":model_name,"metric":"accuracy","class":"","value":accuracy_score(y_true,y_pred)})
    rows.append({"model":model_name,"metric":"precision_macro","class":"","value":precision_score(y_true,y_pred,labels=labels,average="macro",zero_division=0)})
    rows.append({"model":model_name,"metric":"recall_macro","class":"","value":recall_score(y_true,y_pred,labels=labels,average="macro",zero_division=0)})
    rows.append({"model":model_name,"metric":"macro_f1","class":"","value":f1_score(y_true,y_pred,labels=labels,average="macro",zero_division=0)})
    pf=f1_score(y_true,y_pred,labels=labels,average=None,zero_division=0)
    for c,v in zip(labels,pf):
        rows.append({"model":model_name,"metric":"per_class_f1","class":str(c),"value":v})
    return rows

def timed_predict(fn, X, repeats=3):
    times=[]
    result=None
    for _ in range(repeats):
        t=time.perf_counter()
        result=fn(X)
        times.append((time.perf_counter()-t)/max(1,len(X)))
    return result, float(np.median(times)*1000), float(np.percentile(times,90)*1000)

def choose_threshold(y_known, conf_known, y_ood, conf_ood):
    """
    Experimental threshold selection. Objective: maximize balanced accuracy
    between 'known' and 'OOD/UNKNOWN' decisions, using only validation data.
    Decision: confidence < threshold => UNKNOWN.
    """
    known=np.asarray(conf_known,float); ood=np.asarray(conf_ood,float)
    vals=np.unique(np.concatenate([known,ood]))
    if len(vals)>300:
        vals=np.quantile(vals,np.linspace(0.001,0.999,300))
    best=None
    for t in vals:
        known_unknown=(known<t)
        ood_unknown=(ood<t)
        tpr=float(np.mean(ood_unknown)) if len(ood) else float("nan")
        known_reject=float(np.mean(known_unknown)) if len(known) else float("nan")
        known_accept=1-known_reject
        if not len(ood): continue
        bal=(tpr+known_accept)/2
        row=(bal,float(t),tpr,known_accept)
        if best is None or row[0]>best[0]:
            best=row
    return best

def group_robustness(rows, pred, confidence):
    out=[]
    for col in REQUIRED_META:
        groups=sorted(set(str(r.get(col,"")).strip() for r in rows if str(r.get(col,"")).strip() not in ("","nan","None")))
        for g in groups:
            idx=[i for i,r in enumerate(rows) if str(r.get(col,"")).strip()==g]
            if not idx: continue
            yt=[rows[i]["label"] for i in idx]; yp=[str(pred[i]) for i in idx]
            out.append({"condition":col,"value":g,"n":len(idx),
                         "accuracy":accuracy_score(yt,yp),
                         "macro_f1":f1_score(yt,yp,average="macro",zero_division=0),
                         "mean_confidence":float(np.mean(np.asarray(confidence)[idx])),
                         "status":"measured"})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",default=".",help="Project root")
    ap.add_argument("--manifest")
    ap.add_argument("--rf")
    ap.add_argument("--cnn")
    ap.add_argument("--sample-rate",type=int,default=16000)
    ap.add_argument("--output",default=None)
    ap.add_argument("--repeats",type=int,default=3)
    args=ap.parse_args()
    root=Path(args.root).resolve()
    out=Path(args.output).resolve() if args.output else root
    out.mkdir(parents=True,exist_ok=True)
    cm_dir=out/"confusion_matrix"; cm_dir.mkdir(exist_ok=True)

    rows=[]
    manifest_status=""
    if args.manifest:
        rows=load_manifest(Path(args.manifest))
        manifest_status="explicit"
    else:
        auto=root/"data"/"evaluation_manifest.csv"
        if auto.exists():
            rows=load_manifest(auto); manifest_status="auto"
        else:
            rows=discover_manifest(root)
            manifest_status="discovered" if rows else "missing"

    # Resolve paths.
    for r in rows:
        p=Path(r["filepath"])
        if not p.is_absolute(): p=root/p
        r["_path"]=str(p)

    # Find model artifacts only if explicitly supplied; otherwise conservative discovery.
    rf=args.rf
    cnn=args.cnn
    if not rf:
        for p in [root/"models"/"random_forest.joblib",root/"models"/"random_forest.pkl",root/"models"/"rf.joblib",root/"models"/"rf.pkl"]:
            if p.exists(): rf=str(p); break
    if not cnn:
        for p in [root/"models"/"cnn.pt",root/"models"/"cnn.pth",root/"models"/"cnn.pickle"]:
            if p.exists(): cnn=str(p); break

    report=[]
    report.append("# SilentVox P5 — Evaluation, Robustness + UNKNOWN\n")
    report.append("## QC status\n")
    report.append(f"- Evaluation manifest: **{manifest_status}** ({len(rows)} rows)\n")
    report.append(f"- Random Forest artifact: **{rf or 'NOT FOUND'}**\n")
    report.append(f"- CNN artifact: **{cnn or 'NOT FOUND'}**\n")
    if not rows or not rf or not cnn:
        report.append("\n> **P5 is not fully executable on the supplied archive.** The archive contains the M5 acoustic simulation, but no identifiable RF/CNN classifier artifacts and no labeled evaluation dataset/manifest. No accuracy, F1, latency, UNKNOWN, or generalization result is fabricated. Add the classifier artifacts and held-out evaluation audio/manifest, then rerun this script.\n")
    report.append("\n## Required methodology\n")
    report.append("P5 evaluates both classifiers on the same held-out test set. It records accuracy, macro precision/recall, macro-F1, per-class F1, confusion matrices, median and P90 per-sample CPU inference latency, serialized model size, and process RAM. Resource measurements are reported as measurements, not estimates.\n")
    report.append("\n### Confusion analysis\n")
    report.append("For every non-diagonal confusion, P5 ranks the pair and records an investigation note covering data overlap, label ambiguity, feature similarity, and model capacity. The note is a hypothesis to be validated against examples; it is not presented as a proven cause without evidence.\n")
    report.append("\n### UNKNOWN detection\n")
    report.append("The rule is `confidence < threshold → UNKNOWN`. The threshold is selected only on validation data containing in-taxonomy known samples and out-of-taxonomy OOD samples. Test data are not used for threshold selection. The report includes false-confident OOD classifications, OOD unknown-detection rate, known rejection rate, and confidence distributions.\n")
    report.append("\n### Generalization\n")
    report.append("Where manifest metadata exists, evaluation is stratified by recording device, distance, direction, volume, environment, noise source, and SNR. Missing metadata is reported as unavailable rather than inferred.\n")
    report.append("\n## Current archive limitation\n")
    report.append("The supplied `SilentVox_M5` archive is an acoustic-modeling project. Its documented artifacts are simulated speaker/secondary-path/leakage models; those are not a Random Forest or CNN classifier and cannot be substituted for classifier predictions.\n")

    all_metric_rows=[]; robustness=[]; unknown_rows=[]; snr_rows=[]; generalization=[]
    models=[("Random Forest",rf,"rf"),("CNN",cnn,"cnn")]
    for name,path,kind in models:
        if not path or not rows: continue
        # Need audio files for generic adapter.
        test_rows=[r for r in rows if r.get("split","")=="test"]
        if not test_rows:
            test_rows=[r for r in rows if r.get("split","") not in ("train","val","validation","ood","unknown")]
        if not test_rows: continue
        missing=[r["_path"] for r in test_rows if not os.path.exists(r["_path"])]
        if missing:
            continue
        try:
            X=audio_features([r["_path"] for r in test_rows],sr=args.sample_rate)
            model=load_model(path,kind)
            def pred_fn(z):
                return predict_rf(model,z) if kind=="rf" else predict_torch(model,z)
            (pred_idx,proba,classes),lat,p90=timed_predict(pred_fn,X,args.repeats)
            pred=map_predictions(pred_idx,classes,[r["label"] for r in test_rows])
            y=np.asarray([r["label"] for r in test_rows])
            labels=sorted(set(y)|set(pred))
            all_metric_rows += metrics_rows(name,y,pred,labels,proba)
            all_metric_rows.append({"model":name,"metric":"inference_latency_median_ms_per_sample","class":"","value":lat})
            all_metric_rows.append({"model":name,"metric":"inference_latency_p90_ms_per_sample","class":"","value":p90})
            all_metric_rows.append({"model":name,"metric":"model_size_bytes","class":"","value":model_size_bytes(path)})
            all_metric_rows.append({"model":name,"metric":"ram_mb_process_rss","class":"","value":get_memory_mb()})
            cm=confusion_matrix(y,pred,labels=labels)
            cm_path=cm_dir/(kind+"_confusion_matrix.csv")
            cm_rows=[]
            for i in range(len(labels)):
                row={"true_label":labels[i]}
                for j in range(len(labels)):
                    row[f"pred_{labels[j]}"]=cm[i,j]
                cm_rows.append(row)
            write_csv(cm_path,cm_rows,["true_label"]+[f"pred_{c}" for c in labels])
            # ranked confusion pairs
            pairs=[]
            for i,a in enumerate(labels):
                for j,b in enumerate(labels):
                    if i!=j and cm[i,j]>0:
                        pairs.append((int(cm[i,j]),a,b))
            pairs.sort(reverse=True)
            for count,a,b in pairs:
                same=[r for r in test_rows if r["label"]==a]
                report.append(f"\n- **{a} → {b}: {count}**. Investigate: (1) acoustic overlap / recording-condition imbalance in the source examples, (2) label-definition or annotation ambiguity, (3) feature similarity or insufficient discriminative features, and (4) model capacity. This is a diagnostic hypothesis until representative clips are manually reviewed.\n")
            conf=np.max(proba,axis=1) if proba is not None else np.full(len(test_rows),np.nan)
            generalization += [{"model":name,**x} for x in group_robustness(test_rows,pred,conf)]
        except Exception as e:
            report.append(f"\n- **{name} evaluation error:** `{type(e).__name__}: {e}`\n")

    write_csv(out/"MODEL_COMPARISON.csv",all_metric_rows,
              ["model","metric","class","value"])

    # UNKNOWN: use validation + OOD if both are available.
    for name,path,kind in models:
        if not path or not rows: continue
        val=[r for r in rows if r.get("split","") in ("val","validation")]
        ood=[r for r in rows if r.get("split","") in ("ood","unknown")]
        if not val or not ood: continue
        try:
            Xv=audio_features([r["_path"] for r in val],sr=args.sample_rate)
            Xo=audio_features([r["_path"] for r in ood],sr=args.sample_rate)
            model=load_model(path,kind)
            fn=lambda z: predict_rf(model,z) if kind=="rf" else predict_torch(model,z)
            _,pv,_=fn(Xv); _,po,_=fn(Xo)
            cv=np.max(pv,axis=1); co=np.max(po,axis=1)
            best=choose_threshold([r["label"] for r in val],cv,[r["label"] for r in ood],co)
            if best:
                bal,t,tpr,known_accept=best
                for threshold in sorted(set([t]+list(np.round(np.arange(0.1,1.0,0.05),2)))):
                    unknown_rate=float(np.mean(co<threshold))
                    false_conf=float(np.mean(co>=threshold))
                    known_reject=float(np.mean(cv<threshold))
                    unknown_rows.append({"model":name,"threshold":threshold,
                        "ood_unknown_detection_rate":unknown_rate,
                        "ood_false_confident_rate":false_conf,
                        "known_rejection_rate":known_reject,
                        "known_acceptance_rate":1-known_reject,
                        "selection_objective_balanced":bal if abs(threshold-t)<1e-12 else ""})
                report.append(f"\n### {name} UNKNOWN threshold\nSelected threshold **{t:.4f}** from validation known-vs-OOD confidence distributions using balanced acceptance/detection. OOD test performance must still be reported separately if a held-out OOD test split exists.\n")
        except Exception as e:
            report.append(f"\n- **{name} UNKNOWN evaluation error:** `{type(e).__name__}: {e}`\n")
    write_csv(out/"UNKNOWN_THRESHOLD_RESULTS.csv",unknown_rows,
              ["model","threshold","ood_unknown_detection_rate","ood_false_confident_rate","known_rejection_rate","known_acceptance_rate","selection_objective_balanced"])

    # SNR / generalization are based on metadata and existing predictions when available.
    write_csv(out/"GENERALIZATION_RESULTS.csv",generalization,
              ["model","condition","value","n","accuracy","macro_f1","mean_confidence","status"])
    # Populate SNR separately from generalization rows.
    for r in generalization:
        if r["condition"]=="snr_db":
            snr_rows.append(r)
    write_csv(out/"SNR_RESULTS.csv",snr_rows,
              ["model","condition","value","n","accuracy","macro_f1","mean_confidence","status"])

    write_csv(out/"robustness_results.csv",generalization,
              ["model","condition","value","n","accuracy","macro_f1","mean_confidence","status"])
    (out/"EVALUATION_REPORT.md").write_text("\n".join(report),encoding="utf-8")
    print(out/"EVALUATION_REPORT.md")
    print(out/"MODEL_COMPARISON.csv")
    print(out/"UNKNOWN_THRESHOLD_RESULTS.csv")
    print(out/"GENERALIZATION_RESULTS.csv")
    print(out/"SNR_RESULTS.csv")

if __name__=="__main__":
    main()
