import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# SILENTVOX M5 - FREQUENCY-DEPENDENT ACOUSTIC LEAKAGE
# ============================================================
# IMPORTANT:
# These leakage curves are SIMULATION ASSUMPTIONS.
# They are NOT physical headset measurements.
#
# The model shows how different seal conditions can have
# different attenuation/leakage across frequency.
# ============================================================


# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

SAMPLE_RATE = 16000

frequencies = np.logspace(
    np.log10(20),
    np.log10(SAMPLE_RATE / 2),
    2000
)


# ============================================================
# LEAKAGE MODELS
# ============================================================

def good_seal(f):
    """
    Good seal:
    Strong attenuation at low frequencies,
    with increasing leakage toward higher frequencies.
    """

    attenuation_db = (
        35
        - 8 * np.log10(np.maximum(f, 20) / 100)
    )

    attenuation_db = np.clip(
        attenuation_db,
        12,
        40
    )

    return attenuation_db


def partial_seal(f):
    """
    Partial seal:
    Moderate attenuation with greater leakage
    across the frequency range.
    """

    attenuation_db = (
        20
        - 5 * np.log10(np.maximum(f, 20) / 100)
    )

    attenuation_db = np.clip(
        attenuation_db,
        6,
        25
    )

    return attenuation_db


def poor_seal(f):
    """
    Poor seal:
    Much lower acoustic isolation.
    """

    attenuation_db = (
        8
        - 2 * np.log10(np.maximum(f, 20) / 100)
    )

    attenuation_db = np.clip(
        attenuation_db,
        2,
        12
    )

    return attenuation_db


# ------------------------------------------------------------
# Calculate attenuation
# ------------------------------------------------------------

good_attenuation = good_seal(frequencies)

partial_attenuation = partial_seal(frequencies)

poor_attenuation = poor_seal(frequencies)


# ============================================================
# CONVERT ATTENUATION TO LINEAR LEAKAGE
# ============================================================

good_leakage = 10 ** (
    -good_attenuation / 20
)

partial_leakage = 10 ** (
    -partial_attenuation / 20
)

poor_leakage = 10 ** (
    -poor_attenuation / 20
)


# ============================================================
# PRINT REPRESENTATIVE VALUES
# ============================================================

print("=" * 70)
print("SILENTVOX M5 - FREQUENCY-DEPENDENT LEAKAGE MODEL")
print("=" * 70)

print()
print("MODEL STATUS:")
print("SIMULATED FREQUENCY-DEPENDENT ACOUSTIC LEAKAGE")
print("Physical headset measurement : PENDING")
print("Physical seal validation     : PENDING")

print()
print("Representative attenuation values:")

test_frequencies = [
    100,
    500,
    1000,
    2000,
    4000,
    8000
]

for f in test_frequencies:

    g = good_seal(np.array([f]))[0]
    p = partial_seal(np.array([f]))[0]
    b = poor_seal(np.array([f]))[0]

    print(
        f"{f:>5} Hz | "
        f"Good: {g:5.2f} dB | "
        f"Partial: {p:5.2f} dB | "
        f"Poor: {b:5.2f} dB"
    )


# ============================================================
# SAVE NUMERICAL RESULTS
# ============================================================

results = np.column_stack(
    (
        frequencies,
        good_attenuation,
        partial_attenuation,
        poor_attenuation,
        good_leakage,
        partial_leakage,
        poor_leakage
    )
)


np.savetxt(
    "results/frequency_dependent_leakage.csv",
    results,
    delimiter=",",
    header=(
        "Frequency_Hz,"
        "Good_Attenuation_dB,"
        "Partial_Attenuation_dB,"
        "Poor_Attenuation_dB,"
        "Good_Leakage,"
        "Partial_Leakage,"
        "Poor_Leakage"
    ),
    comments=""
)


# ============================================================
# PLOT 1 - ATTENUATION
# ============================================================

plt.figure(figsize=(10, 6))

plt.semilogx(
    frequencies,
    good_attenuation,
    linewidth=2,
    label="Good Seal"
)

plt.semilogx(
    frequencies,
    partial_attenuation,
    linewidth=2,
    label="Partial Seal"
)

plt.semilogx(
    frequencies,
    poor_attenuation,
    linewidth=2,
    label="Poor Seal"
)

plt.title(
    "SilentVox M5 - Simulated Acoustic Attenuation"
)

plt.xlabel(
    "Frequency (Hz)"
)

plt.ylabel(
    "Attenuation (dB)"
)

plt.grid(
    True,
    which="both",
    alpha=0.3
)

plt.legend()

plt.tight_layout()

plt.savefig(
    "plots/frequency_leakage_attenuation.png",
    dpi=300
)

plt.show()


# ============================================================
# PLOT 2 - LEAKAGE TRANSFER
# ============================================================

plt.figure(figsize=(10, 6))

plt.semilogx(
    frequencies,
    20 * np.log10(
        np.maximum(good_leakage, 1e-10)
    ),
    linewidth=2,
    label="Good Seal"
)

plt.semilogx(
    frequencies,
    20 * np.log10(
        np.maximum(partial_leakage, 1e-10)
    ),
    linewidth=2,
    label="Partial Seal"
)

plt.semilogx(
    frequencies,
    20 * np.log10(
        np.maximum(poor_leakage, 1e-10)
    ),
    linewidth=2,
    label="Poor Seal"
)

plt.title(
    "SilentVox M5 - Simulated Leakage Transfer Function"
)

plt.xlabel(
    "Frequency (Hz)"
)

plt.ylabel(
    "Leakage Magnitude (dB)"
)

plt.grid(
    True,
    which="both",
    alpha=0.3
)

plt.legend()

plt.tight_layout()

plt.savefig(
    "plots/frequency_leakage_transfer.png",
    dpi=300
)

plt.show()


# ============================================================
# FINAL OUTPUT
# ============================================================

print()
print("OUTPUT FILES CREATED:")
print("-----------------------------------------")
print("results/frequency_dependent_leakage.csv")
print("plots/frequency_leakage_attenuation.png")
print("plots/frequency_leakage_transfer.png")

print()
print("Frequency-dependent leakage simulation completed.")