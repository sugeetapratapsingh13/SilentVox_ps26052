import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# SILENTVOX M5 - ACOUSTIC LEAKAGE SIMULATION
# ============================================================
# IMPORTANT:
# These are SIMULATED acoustic leakage conditions.
# They are not physical measurements.
#
# The purpose is to study how different headset seal
# conditions could affect the acoustic path.
# ============================================================


# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

SAMPLE_RATE = 16000
DURATION = 2.0

N = int(SAMPLE_RATE * DURATION)

time = np.arange(N) / SAMPLE_RATE


# ============================================================
# TEST SIGNAL
# ============================================================

# Create a broadband test signal containing several
# representative frequency components.

test_signal = (
    0.5 * np.sin(2 * np.pi * 300 * time)
    + 0.4 * np.sin(2 * np.pi * 800 * time)
    + 0.3 * np.sin(2 * np.pi * 1500 * time)
    + 0.2 * np.sin(2 * np.pi * 3000 * time)
)


# Normalize

test_signal = test_signal / np.max(
    np.abs(test_signal)
)


# ============================================================
# LEAKAGE CONDITIONS
# ============================================================

# Leakage coefficient:
#
# Lower value = better acoustic seal
# Higher value = more external sound leakage
#
# These values are simulation assumptions.

leakage_conditions = {

    "Good Seal": 0.10,

    "Partial Seal": 0.35,

    "Poor Seal": 0.70
}


# ============================================================
# APPLY LEAKAGE
# ============================================================

leakage_signals = {}

for condition, leakage_factor in leakage_conditions.items():

    leakage_signals[condition] = (
        test_signal * leakage_factor
    )


# ============================================================
# CALCULATE RMS LEVEL
# ============================================================

rms_results = {}

for condition, signal in leakage_signals.items():

    rms = np.sqrt(
        np.mean(signal ** 2)
    )

    rms_results[condition] = rms


# ============================================================
# PRINT RESULTS
# ============================================================

print("=" * 65)
print("SILENTVOX M5 - ACOUSTIC LEAKAGE SIMULATION")
print("=" * 65)

print()
print("SIMULATION CONDITIONS")
print("---------------------")

for condition, factor in leakage_conditions.items():

    print(
        f"{condition:<18} "
        f"Leakage factor = {factor:.2f}"
    )


print()
print("RMS LEAKAGE LEVELS")
print("------------------")

for condition, rms in rms_results.items():

    print(
        f"{condition:<18} "
        f"RMS = {rms:.4f}"
    )


print()
print("MODEL STATUS:")
print("SIMULATED LEAKAGE MODEL")
print("Physical headset measurement : PENDING")
print("Physical seal validation     : PENDING")


# ============================================================
# SAVE NUMERICAL RESULTS
# ============================================================

output = []

for condition in leakage_conditions:

    output.append([
        condition,
        leakage_conditions[condition],
        rms_results[condition]
    ])


output = np.array(
    output,
    dtype=object
)


np.savetxt(
    "results/leakage_results.csv",
    output,
    delimiter=",",
    fmt="%s",
    header="Condition,Leakage_Factor,RMS_Level",
    comments=""
)


# ============================================================
# PLOT 1 - LEAKAGE COMPARISON
# ============================================================

plt.figure(figsize=(10, 6))

conditions = list(leakage_conditions.keys())

values = [
    leakage_conditions[c]
    for c in conditions
]


plt.bar(
    conditions,
    values
)


plt.title(
    "SilentVox M5 - Simulated Acoustic Leakage"
)

plt.xlabel(
    "Headset Seal Condition"
)

plt.ylabel(
    "Leakage Factor"
)

plt.ylim(0, 0.8)

plt.grid(
    axis="y",
    alpha=0.3
)

plt.tight_layout()

plt.savefig(
    "plots/leakage_comparison.png",
    dpi=300
)

plt.show()


# ============================================================
# PLOT 2 - TIME-DOMAIN COMPARISON
# ============================================================

plt.figure(figsize=(10, 6))

# Display only the first 0.05 seconds

display_samples = int(
    SAMPLE_RATE * 0.05
)


for condition in conditions:

    plt.plot(
        time[:display_samples],
        leakage_signals[condition][:display_samples],
        label=condition
    )


plt.title(
    "SilentVox M5 - Simulated Leakage Waveforms"
)

plt.xlabel(
    "Time (seconds)"
)

plt.ylabel(
    "Amplitude"
)

plt.legend()

plt.grid(
    alpha=0.3
)

plt.tight_layout()

plt.savefig(
    "plots/leakage_waveforms.png",
    dpi=300
)

plt.show()


# ============================================================
# FINAL OUTPUT
# ============================================================

print()
print("OUTPUT FILES CREATED:")
print("---------------------------------")
print("results/leakage_results.csv")
print("plots/leakage_comparison.png")
print("plots/leakage_waveforms.png")

print()
print("Acoustic leakage simulation completed.")