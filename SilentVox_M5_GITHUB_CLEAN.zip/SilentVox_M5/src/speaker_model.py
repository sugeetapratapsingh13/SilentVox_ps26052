import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# SILENTVOX M5 - SPEAKER ACOUSTIC MODEL
# ============================================================
# IMPORTANT:
# These are PROVISIONAL SIMULATION PARAMETERS.
# They are NOT physical measurements.
# Replace them later with values from the selected
# speaker's manufacturer datasheet.
# ============================================================


# -----------------------------
# Speaker parameters
# -----------------------------

SAMPLE_RATE = 16000

IMPEDANCE_OHM = 4.0
SENSITIVITY_DB = 85.0
RATED_POWER_W = 2.0

RESONANCE_HZ = 300.0

LOWER_LIMIT_HZ = 100.0
UPPER_LIMIT_HZ = 8000.0


# -----------------------------
# Frequency range
# -----------------------------

frequencies = np.logspace(
    np.log10(20),
    np.log10(20000),
    2000
)


# ============================================================
# 1. SIMULATED SPEAKER FREQUENCY RESPONSE
# ============================================================

def speaker_frequency_response(f):
    """
    Create a simplified speaker response.

    This is a mathematical approximation used only
    for simulation until the actual speaker datasheet
    is available.
    """

    response = np.zeros_like(f)

    # Low-frequency roll-off
    low_rolloff = 1 / np.sqrt(
        1 + (RESONANCE_HZ / f) ** 4
    )

    # High-frequency roll-off
    high_rolloff = 1 / np.sqrt(
        1 + (f / UPPER_LIMIT_HZ) ** 4
    )

    response = low_rolloff * high_rolloff

    # Convert to dB
    response_db = 20 * np.log10(
        np.maximum(response, 1e-10)
    )

    # Add sensitivity
    response_db += SENSITIVITY_DB

    return response_db


response_db = speaker_frequency_response(frequencies)


# ============================================================
# 2. PRINT SPEAKER PARAMETERS
# ============================================================

print("=" * 60)
print("SILENTVOX M5 - SPEAKER MODEL")
print("=" * 60)

print(f"Sample rate       : {SAMPLE_RATE} Hz")
print(f"Impedance         : {IMPEDANCE_OHM} ohm")
print(f"Sensitivity       : {SENSITIVITY_DB} dB")
print(f"Rated power       : {RATED_POWER_W} W")
print(f"Resonance         : {RESONANCE_HZ} Hz")
print(f"Frequency range   : {LOWER_LIMIT_HZ} - {UPPER_LIMIT_HZ} Hz")

print()
print("MODEL STATUS:")
print("PROVISIONAL SIMULATION")
print("Physical speaker measurement: PENDING")
print("Datasheet validation: PENDING")


# ============================================================
# 3. CREATE FREQUENCY RESPONSE PLOT
# ============================================================

plt.figure(figsize=(10, 6))

plt.semilogx(
    frequencies,
    response_db,
    linewidth=2
)

plt.axvline(
    RESONANCE_HZ,
    linestyle="--",
    label="Resonance"
)

plt.axvline(
    LOWER_LIMIT_HZ,
    linestyle=":",
    label="Lower frequency limit"
)

plt.axvline(
    UPPER_LIMIT_HZ,
    linestyle=":",
    label="Upper frequency limit"
)

plt.title(
    "SilentVox M5 - Simulated Speaker Frequency Response"
)

plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude (dB SPL)")

plt.grid(True, which="both", alpha=0.3)
plt.legend()

plt.tight_layout()

plt.savefig(
    "plots/speaker_frequency_response.png",
    dpi=300
)

plt.show()


# ============================================================
# 4. SAVE NUMERICAL RESULTS
# ============================================================

results = np.column_stack(
    (frequencies, response_db)
)

np.savetxt(
    "results/speaker_frequency_response.csv",
    results,
    delimiter=",",
    header="Frequency_Hz,Response_dB",
    comments=""
)

print()
print("OUTPUT FILES CREATED:")
print("plots/speaker_frequency_response.png")
print("results/speaker_frequency_response.csv")

print()
print("Speaker model completed successfully.")