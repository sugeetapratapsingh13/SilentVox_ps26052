import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import freqz


# ============================================================
# SILENTVOX M5 - COMBINED ACOUSTIC MODEL
# ============================================================
# IMPORTANT:
# This is a SIMULATED acoustic model.
#
# It combines:
#   1. Speaker response
#   2. Secondary-path model
#   3. Frequency-dependent acoustic leakage
#
# Physical headset/speaker/error-microphone validation
# is still pending.
# ============================================================


# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

SAMPLE_RATE = 16000

FILTER_LENGTH = 128

DELAY_MS = 2.0

ATTENUATION = 0.65

RESONANCE_HZ = 300.0

UPPER_LIMIT_HZ = 8000.0

SENSITIVITY_DB = 85.0


# ============================================================
# FREQUENCY AXIS
# ============================================================

frequencies = np.linspace(
    20,
    SAMPLE_RATE / 2,
    2000
)


# ============================================================
# 1. SPEAKER RESPONSE
# ============================================================

def speaker_response(f):
    """
    Simplified mathematical speaker response.

    Provisional simulation only.
    """

    low_rolloff = 1 / np.sqrt(
        1 + (RESONANCE_HZ / f) ** 4
    )

    high_rolloff = 1 / np.sqrt(
        1 + (f / UPPER_LIMIT_HZ) ** 4
    )

    response = (
        low_rolloff
        * high_rolloff
    )

    response_db = (
        20 * np.log10(
            np.maximum(response, 1e-10)
        )
        + SENSITIVITY_DB
    )

    return response_db


speaker_db = speaker_response(
    frequencies
)


# ============================================================
# 2. SECONDARY PATH
# ============================================================

delay_samples = int(
    SAMPLE_RATE
    * DELAY_MS
    / 1000
)


secondary_path = np.zeros(
    FILTER_LENGTH
)


if delay_samples >= FILTER_LENGTH:

    raise ValueError(
        "Delay is longer than filter length."
    )


secondary_path[
    delay_samples
] = ATTENUATION


# Acoustic tail

tail_start = delay_samples + 1

if tail_start < FILTER_LENGTH:

    tail_length = (
        FILTER_LENGTH
        - tail_start
    )

    tail = (
        ATTENUATION
        * 0.25
        * np.exp(
            -np.linspace(
                0,
                5,
                tail_length
            )
        )
    )

    secondary_path[
        tail_start:
    ] = tail


# Frequency response

w, h = freqz(
    secondary_path,
    worN=4096,
    fs=SAMPLE_RATE
)


secondary_magnitude = (
    np.abs(h)
)

secondary_db = (
    20
    * np.log10(
        np.maximum(
            secondary_magnitude,
            1e-10
        )
    )
)


# ============================================================
# 3. FREQUENCY-DEPENDENT LEAKAGE
# ============================================================

def leakage_attenuation(
    f,
    condition
):

    if condition == "Good Seal":

        attenuation = (
            35
            - 8
            * np.log10(
                np.maximum(f, 20)
                / 100
            )
        )

        return np.clip(
            attenuation,
            12,
            40
        )

    elif condition == "Partial Seal":

        attenuation = (
            20
            - 5
            * np.log10(
                np.maximum(f, 20)
                / 100
            )
        )

        return np.clip(
            attenuation,
            6,
            25
        )

    elif condition == "Poor Seal":

        attenuation = (
            8
            - 2
            * np.log10(
                np.maximum(f, 20)
                / 100
            )
        )

        return np.clip(
            attenuation,
            2,
            12
        )

    else:

        raise ValueError(
            "Unknown seal condition."
        )


# ============================================================
# 4. COMBINED ACOUSTIC RESPONSE
# ============================================================

conditions = [
    "Good Seal",
    "Partial Seal",
    "Poor Seal"
]


combined_results = {}


for condition in conditions:

    # Leakage transfer magnitude

    leakage_db = (
        -leakage_attenuation(
            frequencies,
            condition
        )
    )

    # Interpolate secondary-path response
    # onto our frequency axis

    secondary_interp = np.interp(
        frequencies,
        w,
        secondary_db
    )

    # Normalize speaker response around
    # its maximum value.

    speaker_normalized = (
        speaker_db
        - np.max(speaker_db)
    )

    # Combined acoustic response

    combined_db = (
        speaker_normalized
        + secondary_interp
        + leakage_db
    )

    combined_results[
        condition
    ] = combined_db


# ============================================================
# 5. PRINT MODEL INFORMATION
# ============================================================

print("=" * 70)
print("SILENTVOX M5 - COMBINED ACOUSTIC MODEL")
print("=" * 70)

print()
print("MODEL PARAMETERS")
print("----------------")

print(
    f"Sample rate       : "
    f"{SAMPLE_RATE} Hz"
)

print(
    f"Secondary delay   : "
    f"{DELAY_MS} ms"
)

print(
    f"Delay samples     : "
    f"{delay_samples}"
)

print(
    f"Filter length     : "
    f"{FILTER_LENGTH} samples"
)

print(
    f"Speaker resonance : "
    f"{RESONANCE_HZ} Hz"
)

print(
    f"Speaker sensitivity: "
    f"{SENSITIVITY_DB} dB"
)


print()
print("MODEL STATUS")
print("------------")

print(
    "SIMULATED COMBINED ACOUSTIC MODEL"
)

print(
    "Physical speaker measurement       : PENDING"
)

print(
    "Physical headset measurement       : PENDING"
)

print(
    "Error-microphone measurement       : PENDING"
)


# ============================================================
# 6. SAVE COMBINED RESULTS
# ============================================================

output = np.column_stack(
    (
        frequencies,
        combined_results["Good Seal"],
        combined_results["Partial Seal"],
        combined_results["Poor Seal"]
    )
)


np.savetxt(
    "results/combined_acoustic_model.csv",
    output,
    delimiter=",",
    header=(
        "Frequency_Hz,"
        "Good_Seal_dB,"
        "Partial_Seal_dB,"
        "Poor_Seal_dB"
    ),
    comments=""
)


# ============================================================
# 7. SAVE MODEL PARAMETERS
# ============================================================

parameters = np.array(
    [
        SAMPLE_RATE,
        FILTER_LENGTH,
        DELAY_MS,
        delay_samples,
        ATTENUATION,
        RESONANCE_HZ,
        UPPER_LIMIT_HZ,
        SENSITIVITY_DB
    ]
)


np.save(
    "models/acoustic_model_parameters.npy",
    parameters
)


# ============================================================
# 8. PLOT COMBINED ACOUSTIC RESPONSE
# ============================================================

plt.figure(
    figsize=(11, 6)
)


for condition in conditions:

    plt.semilogx(
        frequencies,
        combined_results[condition],
        linewidth=2,
        label=condition
    )


plt.title(
    "SilentVox M5 - Combined Simulated Acoustic Response"
)

plt.xlabel(
    "Frequency (Hz)"
)

plt.ylabel(
    "Combined Response (dB)"
)

plt.grid(
    True,
    which="both",
    alpha=0.3
)

plt.legend()

plt.tight_layout()


plt.savefig(
    "plots/combined_acoustic_response.png",
    dpi=300
)


plt.show()


# ============================================================
# 9. COMPARISON AT IMPORTANT FREQUENCIES
# ============================================================

print()
print("COMBINED RESPONSE AT SELECTED FREQUENCIES")
print("------------------------------------------")


test_frequencies = [
    100,
    500,
    1000,
    2000,
    4000,
    8000
]


for f in test_frequencies:

    print()
    print(f"{f} Hz")

    for condition in conditions:

        value = np.interp(
            f,
            frequencies,
            combined_results[condition]
        )

        print(
            f"  {condition:<15} "
            f"{value:>8.2f} dB"
        )


# ============================================================
# FINAL MESSAGE
# ============================================================

print()
print("=" * 70)
print("OUTPUT FILES CREATED")
print("=" * 70)

print(
    "results/combined_acoustic_model.csv"
)

print(
    "models/acoustic_model_parameters.npy"
)

print(
    "plots/combined_acoustic_response.png"
)

print()
print(
    "Combined acoustic model completed successfully."
)