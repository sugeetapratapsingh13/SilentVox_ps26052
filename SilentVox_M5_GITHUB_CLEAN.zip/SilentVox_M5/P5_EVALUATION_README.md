# P5 — Evaluation + Robustness + UNKNOWN

P5 is a **quality-control/evaluation stage only**. It does not train another
model and it does not change classifier weights.

## What P5 measures

For both Random Forest and CNN, when artifacts and held-out audio are present:

- accuracy
- macro precision
- macro recall
- macro-F1
- per-class F1
- confusion matrix
- median and P90 CPU inference latency per sample
- serialized model size
- process RAM usage

## Confusion analysis

P5 ranks non-diagonal errors such as:

`ENGINE → MACHINERY`  
`ROTOR → ENGINE`  
`WIND → NOISE`

and writes diagnostic notes addressing four possible causes:

1. **Data** — class overlap, recording-condition imbalance, insufficient examples.
2. **Labels** — ambiguous class definitions or annotation errors.
3. **Features** — acoustically similar classes not separated by the feature representation.
4. **Model capacity** — the classifier may lack enough capacity or the architecture/features may be mismatched.

These are hypotheses for manual clip review, not claims of causation without evidence.

## UNKNOWN detection

The operational rule is:

```text
confidence < threshold
        ↓
     UNKNOWN
```

The threshold is **experimentally selected on validation data**, using both
known in-taxonomy samples and out-of-taxonomy (OOD) samples. The test set is
not used to choose the threshold.

Reported quantities include:

- OOD unknown-detection rate
- false-confident OOD rate
- known-sample rejection rate
- known acceptance rate
- confidence/threshold sweep

## Generalization / robustness

The evaluation manifest can contain:

- `device`
- `distance`
- `direction`
- `volume`
- `environment`
- `noise_source`
- `snr_db`

P5 stratifies results by each available condition. Missing metadata is reported
as unavailable rather than guessed.

## Evaluation manifest

Create `data/evaluation_manifest.csv`:

```csv
filepath,label,split,device,distance,direction,volume,environment,noise_source,snr_db
audio/test/engine_01.wav,ENGINE,test,phone_A,1m,front,normal,indoor,engine,20
audio/val/engine_02.wav,ENGINE,val,phone_A,1m,front,normal,indoor,engine,20
audio/ood/fan.wav,UNKNOWN,ood,phone_A,1m,front,normal,indoor,fan,20
```

`filepath` and `label` are mandatory. The other columns enable robustness
analysis. Use `split=ood` for sounds outside the training taxonomy.

## Model artifacts

By default P5 looks for:

```text
models/random_forest.joblib
models/random_forest.pkl
models/rf.joblib
models/rf.pkl

models/cnn.pt
models/cnn.pth
models/cnn.pickle
```

They can also be supplied explicitly.

**Important:** the generic audio adapter uses log-mel/MFCC/statistical features.
If the original classifier was trained with a different feature pipeline,
replace `audio_features()` with the project's exact preprocessing. Otherwise
the evaluation would not be valid.

For a PyTorch CNN, the checkpoint must contain a CPU-loadable model object.
A bare `state_dict` requires a project-specific architecture adapter.

## Run

From the project root:

```bash
python src/evaluation/p5_evaluation.py --root .
```

Or explicitly:

```bash
python src/evaluation/p5_evaluation.py \
  --root . \
  --manifest data/evaluation_manifest.csv \
  --rf models/random_forest.joblib \
  --cnn models/cnn.pt
```

Dependencies for a full run include `numpy`, `scikit-learn`, `librosa`, and
`psutil`; PyTorch is required for CNN evaluation.

## Deliverables

P5 writes:

```text
EVALUATION_REPORT.md
confusion_matrix/
robustness_results.csv
SNR_RESULTS.csv
UNKNOWN_THRESHOLD_RESULTS.csv
GENERALIZATION_RESULTS.csv
MODEL_COMPARISON.csv
```

The supplied M5 archive does **not** contain the RF/CNN classifiers or a
labeled evaluation dataset, so the included initial report deliberately marks
those measurements as unavailable. No synthetic accuracy or robustness score
is inserted.
