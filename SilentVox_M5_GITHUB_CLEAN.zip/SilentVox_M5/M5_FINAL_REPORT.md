# SilentVox M5 — Headset + Acoustic Modelling

## 1. Objective

M5 develops a preliminary digital acoustic model for the SilentVox
headset before physical acoustic measurements are available.

The model focuses on:

- Speaker acoustic response
- Simulated secondary path
- Acoustic delay
- Acoustic attenuation
- Frequency-dependent leakage
- Different headset seal conditions
- M5 → M1 FxLMS handoff

All current acoustic results are simulations. Physical validation is
pending.

---

## 2. System Architecture

The simulated acoustic pathway is:

External / anti-noise signal
        ↓
Acoustic leakage
        ↓
Speaker response
        ↓
Secondary acoustic path
        ↓
Acoustic delay
        ↓
Error microphone
        ↓
Simulated Ŝ(z)

The resulting secondary-path estimate can be supplied to M1 for
FxLMS experimentation.

---

## 3. Speaker Acoustic Model

A parameterized speaker model was created.

Current provisional parameters:

| Parameter | Value |
|---|---:|
| Sample rate | 16 kHz |
| Impedance | 4 Ω |
| Sensitivity | 85 dB |
| Rated power | 2 W |
| Resonance | 300 Hz |
| Frequency range | 100 Hz – 8 kHz |

These values are simulation parameters and are not physical
measurements of the final speaker.

The model generates a simulated frequency-response curve.

Output:

`plots/speaker_frequency_response.png`

Numerical response:

`results/speaker_frequency_response.csv`

---

## 4. Secondary-Path Model

A simulated secondary-path impulse response was created.

Parameters:

| Parameter | Value |
|---|---:|
| Sample rate | 16 kHz |
| Filter length | 128 samples |
| Delay | 2 ms |
| Delay samples | 32 |
| Attenuation | 0.65 |

The model contains a delayed acoustic component and a decaying
acoustic tail.

The simulated secondary-path estimate is stored as:

`models/secondary_path_estimate.npy`

Frequency-response results:

`results/secondary_path_response.csv`

Plots:

`plots/secondary_path_magnitude.png`

`plots/secondary_path_phase.png`

---

## 5. Acoustic Leakage Model

Three headset seal conditions were simulated.

### Good Seal

Leakage factor:

0.10

### Partial Seal

Leakage factor:

0.35

### Poor Seal

Leakage factor:

0.70

The resulting RMS leakage levels were:

| Condition | Leakage Factor | RMS |
|---|---:|---:|
| Good Seal | 0.10 | 0.0400 |
| Partial Seal | 0.35 | 0.1402 |
| Poor Seal | 0.70 | 0.2803 |

These are simulated values.

Output:

`results/leakage_results.csv`

Plots:

`plots/leakage_comparison.png`

`plots/leakage_waveforms.png`

---

## 6. Frequency-Dependent Leakage

A frequency-dependent leakage model was implemented for:

- Good Seal
- Partial Seal
- Poor Seal

The model produces different acoustic attenuation characteristics
across frequency.

Output:

`results/frequency_dependent_leakage.csv`

Plots:

`plots/frequency_leakage_attenuation.png`

`plots/frequency_leakage_transfer.png`

These curves are simulation assumptions and require physical
validation later.

---

## 7. Combined Acoustic Model

The speaker model, secondary path, and frequency-dependent leakage
model were combined into a single simulated acoustic response.

The combined response was generated for:

- Good Seal
- Partial Seal
- Poor Seal

Output:

`results/combined_acoustic_model.csv`

Model parameters:

`models/acoustic_model_parameters.npy`

Plot:

`plots/combined_acoustic_response.png`

This represents the current preliminary digital acoustic model for
SilentVox.

---

## 8. Acoustic Delay Experiment

The effect of secondary-path delay was investigated using:

- 0 ms
- 1 ms
- 2 ms
- 5 ms
- 10 ms

At a 16 kHz sample rate:

| Delay | Samples |
|---:|---:|
| 0 ms | 0 |
| 1 ms | 16 |
| 2 ms | 32 |
| 5 ms | 80 |
| 10 ms | 160 |

The experiment demonstrates the frequency-dependent phase shift
associated with increasing acoustic delay.

Outputs:

`results/delay_phase_results.csv`

`results/delay_magnitude_results.csv`

Plots:

`plots/delay_phase_comparison.png`

`plots/delay_magnitude_comparison.png`

---

## 9. M5 → M1 Handoff

M5 provides M1 with:

- Simulated secondary-path impulse response
- Acoustic delay
- Attenuation
- Frequency response
- Leakage scenarios
- Combined acoustic response

Primary model:

`models/secondary_path_estimate.npy`

Recommended initial parameters:

```text
Sample rate       = 16000 Hz
Filter length     = 128 samples
Delay             = 2 ms
Delay samples     = 32
Attenuation       = 0.65

## 10. P5 Evaluation + Robustness

A dedicated P5 quality-control module has been added under:

`src/evaluation/p5_evaluation.py`

P5 is evaluation-only and does not train another classifier. It is designed
to evaluate both the Random Forest and CNN on the same held-out data and
produce:

- accuracy
- precision
- recall
- macro-F1
- per-class F1
- confusion matrices
- CPU inference latency
- serialized model size
- RAM usage
- confusion-pair investigation
- experimentally selected UNKNOWN confidence threshold
- false-confident OOD rate
- UNKNOWN detection rate
- confidence distribution results
- device/distance/direction/volume/environment/noise/SNR generalization results

Required deliverables:

`EVALUATION_REPORT.md`  
`confusion_matrix/`  
`robustness_results.csv`  
`SNR_RESULTS.csv`  
`UNKNOWN_THRESHOLD_RESULTS.csv`  
`GENERALIZATION_RESULTS.csv`  
`MODEL_COMPARISON.csv`

### P5 status for this archive

The supplied M5 archive does not contain the Random Forest classifier, CNN
classifier, or a labeled evaluation/OOD audio manifest. Therefore P5 creates
an explicit NOT-MEASURABLE report and empty result tables with headers rather
than inventing accuracy, F1, latency, UNKNOWN, or robustness values.

This is important for QC: simulated M5 acoustic models must not be treated as
classification models.

After the classifier artifacts and held-out manifest are supplied, run:

```text
python src/evaluation/p5_evaluation.py --root .
```

See `P5_EVALUATION_README.md` for the manifest format and evaluation rules.
