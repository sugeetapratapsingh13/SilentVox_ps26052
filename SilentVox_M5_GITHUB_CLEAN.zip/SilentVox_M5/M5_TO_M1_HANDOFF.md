# M5 → M1 HANDOFF
## Simulated Acoustic Secondary Path for FxLMS Testing

---

## 1. Purpose

M5 provides M1 with a simulated acoustic secondary-path model for
testing the FxLMS ANC algorithm before physical headset measurements
are available.

The model represents:

External/anti-noise signal
        ↓
Speaker
        ↓
Acoustic delay
        ↓
Acoustic attenuation
        ↓
Frequency-dependent leakage
        ↓
Error microphone

The resulting model is treated as:

Ŝ(z)

---

## 2. Model Status

STATUS:

Simulated secondary-path estimate — physical measurement pending.

The current model is NOT a measured representation of the final
physical headset.

Physical validation will be required after the speaker, headset
enclosure, acoustic path, and error microphone are available.

---

## 3. Current Simulation Parameters

Sample rate:
16000 Hz

Secondary-path filter length:
128 samples

Simulated acoustic delay:
2.0 ms

Delay in samples:
32 samples

Overall secondary-path attenuation:
0.65

Speaker resonance assumption:
300 Hz

Speaker sensitivity assumption:
85 dB

Provisional speaker operating range:
100 Hz – 8000 Hz

---

## 4. Secondary-Path Model

The current simulated secondary path consists of:

1. Direct delayed acoustic component
2. Overall attenuation
3. Exponentially decaying acoustic tail

The model is stored as:

models/secondary_path_estimate.npy

M1 can load this file as the current simulated secondary-path
impulse response.

---

## 5. Leakage Conditions

Three simulated headset-seal conditions were created.

### Good Seal

Leakage factor:

0.10

Interpretation:

Low simulated external acoustic leakage.

---

### Partial Seal

Leakage factor:

0.35

Interpretation:

Moderate simulated external acoustic leakage.

---

### Poor Seal

Leakage factor:

0.70

Interpretation:

High simulated external acoustic leakage.

---

## 6. Frequency-Dependent Leakage

A frequency-dependent leakage model was also created.

The model contains separate simulated attenuation curves for:

- Good Seal
- Partial Seal
- Poor Seal

The results are stored in:

results/frequency_dependent_leakage.csv

The corresponding plots are:

plots/frequency_leakage_attenuation.png

plots/frequency_leakage_transfer.png

These curves are simulation assumptions and are not physical
measurements of the final headset.

---

## 7. Combined Acoustic Model

M5 combines:

Speaker response
        +
Secondary-path response
        +
Frequency-dependent leakage

to produce a combined simulated acoustic response.

The combined results are stored in:

results/combined_acoustic_model.csv

Model parameters are stored in:

models/acoustic_model_parameters.npy

Plot:

plots/combined_acoustic_response.png

---

## 8. Delay Experiments

M5 tested the following simulated secondary-path delays:

0 ms
1 ms
2 ms
5 ms
10 ms

At 16 kHz these correspond to:

0 ms  → 0 samples
1 ms  → 16 samples
2 ms  → 32 samples
5 ms  → 80 samples
10 ms → 160 samples

Results:

results/delay_phase_results.csv

results/delay_magnitude_results.csv

Plots:

plots/delay_phase_comparison.png

plots/delay_magnitude_comparison.png

The delay experiment demonstrates the strong frequency-dependent
phase shift introduced by acoustic delay.

---

## 9. Files Available to M1

### Secondary-path model

models/secondary_path_estimate.npy

### Combined acoustic model

results/combined_acoustic_model.csv

### Leakage model

results/frequency_dependent_leakage.csv

### Delay experiment

results/delay_phase_results.csv

results/delay_magnitude_results.csv

---

## 10. Recommended M1 Usage

M1 should initially use:

Sample rate = 16000 Hz

Secondary-path filter length = 128 samples

Secondary-path delay = 32 samples

Attenuation = 0.65

Secondary-path impulse response:

models/secondary_path_estimate.npy

The model can be used as Ŝ(z) for initial FxLMS simulation.

---

## 11. Important Limitation

The current Ŝ(z) is a simulated model.

It must NOT be described as:

"Measured secondary path"

or

"Measured headset acoustic response"

Instead describe it as:

"Simulated secondary-path estimate — physical measurement pending."

---

## 12. Future Physical Validation

When the physical system becomes available, M5 should replace or
refine the simulated model using measured:

- speaker response
- acoustic delay
- enclosure response
- headset leakage
- error-microphone response
- phase response
- magnitude response

The measured secondary path should then replace the provisional
simulation in the FxLMS experiments.

---

## 13. M5 → M1 Interface

M5 provides:

Ŝ(z)
+
delay characteristics
+
frequency response
+
leakage scenarios

M1 uses these inputs for:

FxLMS filtering
adaptive-weight updates
ANC convergence experiments
robustness testing

---

## 14. Current Conclusion

M5 has produced a complete preliminary digital acoustic model that
can be used to test the ANC/FxLMS pipeline before physical headset
measurements are available.

Physical validation remains pending.