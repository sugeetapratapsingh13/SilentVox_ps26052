# Confusion-matrix outputs

When P5 has classifier + test-set artifacts, this directory receives:

- `rf_confusion_matrix.csv`
- `cnn_confusion_matrix.csv`

Each matrix is generated from the held-out test set. P5 also ranks each
non-diagonal pair in `EVALUATION_REPORT.md` and asks whether the likely source
is data overlap, label ambiguity, feature similarity, or model capacity.

No matrix is fabricated when the required classifier/test artifacts are absent.
